<?php
class Hello extends CI_Controller {
	function index(){
	echo"Hello";
	}

}


